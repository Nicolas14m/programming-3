﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTOs_Compra
{
    public class DTO_Planta
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public string Ambiente { get; set; }
        public string Descripcion { get; set; }
        public int CantidadPorPlanta { get; set; }
        public decimal PrecioUnitario { get; set; }
    }
}
