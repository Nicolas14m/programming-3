﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTOs_Compra
{
    public class DTO_Compra
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public decimal Total { get; set; }
        public decimal TasaCobradaIVA { get; set; }
        public string NombresCientificos { get; set; }
        public decimal TasaCobradaImportacion { get; set; } 
        public decimal PorcentajeDescuentoArancel { get; set; }
        public decimal MontoImpuestos { get; set; }

        public IEnumerable<DTO_Planta> PlantasCompra { get; set; }

    }
}
