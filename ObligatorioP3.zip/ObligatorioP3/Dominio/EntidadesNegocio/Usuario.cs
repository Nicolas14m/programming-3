using Dominio.OtrasInterfaces;
using System.ComponentModel.DataAnnotations;

namespace Dominio.EntidadesNegocio
{
	public class Usuario : IValidate
	{
		public int Id{ get; set; }

		public string Email{ get; set; }

		public string Password{ get; set; }


        public bool Validar()
        {
            return ValidarPassword(Password) && ValidarEmail(Email);
        }

        public bool ValidarPassword(string password) {

            string mayusculas = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string minusculas = "abcdefghijklmnoupqrstuvwxyz";
            string digitos = "0123456789";

            bool tieneMayuscula = false;
            bool tieneMinuscula = false;
            bool tieneDigito = false;

            if (password.Length >= 6)
            {

                foreach (char c in password)
                {

                    if (mayusculas.Contains(c))
                    {
                        tieneMayuscula = true;
                    }

                    if (minusculas.Contains(c))
                    {
                        tieneMinuscula = true;
                    }

                    if (digitos.Contains(c))
                    {
                        tieneDigito = true;
                    }


                }

                if (tieneMayuscula && tieneMinuscula && tieneDigito)
                {
                    return true;
                }

                return false;
            }

            return false;
        }

        public bool ValidarEmail(string email)
        {
            bool esValido;
            var emailAttribute = new EmailAddressAttribute();

            esValido = emailAttribute.IsValid(email);

            return esValido;
        }



    }

}

