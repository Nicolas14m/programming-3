using System;
using System.Collections.Generic;
using Dominio.EntidadesNegocio;
using Dominio.OtrasInterfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
	public abstract class Compra 
	{
		public int Id{ get; set; }

        [Required]
		public DateTime Fecha{ get; set; }

		public IEnumerable<ItemCompra> ItemsCompras { get; set; }

		public abstract decimal CalcTotal();

		public abstract decimal CalcImpuesto();

    }

}

