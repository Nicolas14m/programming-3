using Dominio.EntidadesNegocio;
using Dominio.OtrasInterfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
	public class Importacion : Compra, IValidate
	{

        [Required]
		public bool OrigenAmericaSur{ get; set; }

		[Required]
		public string DescMedidasSanitarias{ get; set; }

		[Column(TypeName = "decimal(10,2)")]
		[Required]
		public decimal TasaCobradaImportacion{ get; set; } // DGI
		[Required]
		[Column(TypeName = "decimal(10,2)")]
		public decimal PorcentajeDescuentoArancel{ get; set; }

        public override decimal CalcImpuesto()
        {
			return 3;
        }

        public override decimal CalcTotal()
        {
            decimal total = 0;

            foreach (var item in ItemsCompras)
            {
                total += (item.PrecioCompraUnitario * item.Cantidad);
            }
            
            total += total + (total * TasaCobradaImportacion / 100);

            if (OrigenAmericaSur) {
                total = total - (total * PorcentajeDescuentoArancel / 100);

            }

            return total;
        }

        public bool Validar()
        {
			return !string.IsNullOrEmpty(DescMedidasSanitarias);

		}
    }

}

