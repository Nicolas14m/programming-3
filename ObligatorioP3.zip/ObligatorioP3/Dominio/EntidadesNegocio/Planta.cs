using Dominio.EntidadesNegocio;
using Dominio.OtrasInterfaces;
using System.Collections.Generic;
using System.IO;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
    public class Planta : IValidate
	{

		public int Id{ get; set; }

        [Required(ErrorMessage = "Elija un tipo de planta")]
		public TipoPlanta Tipo{ get; set; }


        [Required(ErrorMessage = "Este campo es requerido")]

        public string NombreCientifico{ get; set; }

        [Required(ErrorMessage = "Este campo es requerido")]
        public string Foto { get; set; }


        [Required(ErrorMessage = "Este campo es requerido")]
        public string NombreVulgar{ get; set; }

        [Required(ErrorMessage = "Este campo es requerido")]
        public string Descripcion { get; set; }

        [Required(ErrorMessage = "Elija un tipo de ambiente")]
        public Ambiente Ambiente{ get; set; }

        [Required(ErrorMessage = "Ingrese una altura"), Range(1, 30000, ErrorMessage ="La altura debe ser mayor a 0")]
        public int AlturaMaxima{ get; set; }

		public FichaCuidado FichaCuidados { get; set; }


        public IEnumerable<ItemCompra> ItemsCompras { get; set; }


        public bool Validar()
        {
			return Tipo.Validar() && ValidarFoto(Foto) && !string.IsNullOrEmpty(Foto) && Ambiente.Validar() && FichaCuidados.Validar() && !string.IsNullOrEmpty(NombreCientifico) && !string.IsNullOrEmpty(Descripcion) && !string.IsNullOrEmpty(NombreVulgar);
        }

        public bool ValidarFoto(string nombreArchivo)
        {
            string ext = Path.GetExtension(nombreArchivo);
            switch (ext.ToLower())
            {
                case ".jpg":
                    return true;
                case ".png":
                    return true;
                default:
                    return false;
            }
        }

    }

}

