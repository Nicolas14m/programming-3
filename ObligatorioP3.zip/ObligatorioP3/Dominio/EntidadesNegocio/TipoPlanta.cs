using Dominio.OtrasInterfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
	public class TipoPlanta : IValidate
	{
		public int Id{ get; set; }

        
        [Required(ErrorMessage = "Este campo es requerido")]
        public string Nombre{ get; set; }

        [Required(ErrorMessage = "Este campo es requerido")]
        public string Descripcion{ get; set; }

        public bool Validar()
        {
            return !string.IsNullOrEmpty(Nombre) && !string.IsNullOrEmpty(Descripcion);
        }
    }

}

