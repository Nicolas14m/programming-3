using Dominio.EntidadesNegocio;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
	public class ItemCompra
	{

		public int Id{ get; set; }

		public Planta Planta{ get; set; }

		public Compra Compra { get; set; }

        [Required]
		public int Cantidad{ get; set; }

		[Required, Range(0, 9999999999)]
		[Column(TypeName = "decimal(10,2)")]
		public decimal PrecioCompraUnitario{ get; set; }

		public int PlantaId { get; set; }
		public int CompraId { get; set; }

	}

}

