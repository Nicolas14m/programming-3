using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
	public class Parametro
	{
        [Key]
		public int Id { get; set; }

        [Required]
		public string Nombre { get; set; }

		[Required]
		[Column(TypeName = "decimal(10,2)")]
		public decimal Valor { get; set; }

		public string Descripcion { get; set; }
	}

}

