using Dominio.EntidadesNegocio;
using Dominio.OtrasInterfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
	public class Plaza : Compra, IValidate
	{
		[Column(TypeName = "decimal(10,2)")]
		public decimal CostoFlete{ get; set; }
		[Column(TypeName = "decimal(10,2)")]
		public decimal TasaCobradaIVA { get; set; }

        public override decimal CalcImpuesto()
        {
            return 230;
        }

        public override decimal CalcTotal()
        {
            decimal total = 0;

            foreach (var item in ItemsCompras) {
                total += (item.PrecioCompraUnitario * item.Cantidad);
            }
            total += CostoFlete;
            total = total + (total * TasaCobradaIVA / 100);
            return total;
        }

        public bool Validar()
        {
			return CostoFlete >= 0;
		}
    }

}

