﻿using Dominio.OtrasInterfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
    public class Ambiente : IValidate
    {
        public int Id { get; set; }


        [Required]
        public string Nombre { get; set; }

        public bool Validar()
        {
            return !string.IsNullOrEmpty(Nombre);
        }
    }
}
