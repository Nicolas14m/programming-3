using Dominio.EntidadesNegocio;
using Dominio.OtrasInterfaces;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.EntidadesNegocio
{
    [Table("FichasCuidado")]
	public class FichaCuidado : IValidate
	{
		public int Id{ get; set; }

        [Required]
        public int FrecuenciaRiego { get; set; }

        [Required]
        public string FrecuenciaUnidadTiempo { get; set; }

        [Required]
        public TipoIluminacion TipoIluminacion{ get; set; }

        [Required, Range(0,100, ErrorMessage ="La temperatura debe ser mayor o igual a 0")]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Temperatura{ get; set; }

        public bool Validar()
        {
            return !string.IsNullOrEmpty(FrecuenciaUnidadTiempo) && !string.IsNullOrEmpty(FrecuenciaUnidadTiempo) && !string.IsNullOrEmpty(FrecuenciaUnidadTiempo) && TipoIluminacion.Validar();
        }
    }

}

