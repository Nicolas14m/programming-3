using Dominio.OtrasInterfaces;

namespace Dominio.EntidadesNegocio
{
	public class TipoIluminacion : IValidate
	{
		public int Id{ get; set; }

		public string Tipo{ get; set; }

		public string Descripcion{ get; set; }

        public bool Validar()
        {
            return !string.IsNullOrEmpty(Tipo) && !string.IsNullOrEmpty(Descripcion);
        }
    }

}

