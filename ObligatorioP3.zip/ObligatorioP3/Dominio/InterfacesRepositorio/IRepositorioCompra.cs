using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using System.Collections.Generic;

namespace Dominio.Interfaces
{
	public interface IRepositorioCompra : IRepositorio<Compra>
	{

		IEnumerable<Compra> ObtenerComprasPorTipoPlanta(string tipo);

	}

}

