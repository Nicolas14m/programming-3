using Dominio.Interfaces;
using Dominio.EntidadesNegocio;

namespace Dominio.Interfaces
{
	public interface IRepositorioUsuario : IRepositorio<Usuario>
	{
		bool Login(string email, string password);

		bool Logout();

		bool ExisteEmail(string email);

	}

}

