﻿using System.Collections.Generic;

namespace Dominio.Interfaces
{
    public interface IRepositorio<T> where T : class
    {

        bool Add(T obj);

        bool Remove(int id);

        bool Update(T obj);

        IEnumerable<T> FindAll();

        T FindById(int id);

    }
}