using Dominio.Interfaces;
using Dominio.EntidadesNegocio;
using System.Collections.Generic;

namespace Dominio.Interfaces
{
	public interface IRepositorioTipo : IRepositorio<TipoPlanta>
	{
		IEnumerable<TipoPlanta> EncontrarPorNombre(string nombre);

		bool TipoYaExiste(string nombreTipo);

		bool TipoEnUso(int idTipo);

		bool ExisteTipo(int idTipo);
	}

}

