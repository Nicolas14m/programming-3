using Dominio.Interfaces;
using System.Collections.Generic;
using Dominio.EntidadesNegocio;

namespace Dominio.Interfaces
{
	public interface IRepositorioPlanta : IRepositorio<Planta>
	{
		List<Planta> BuscarPorTexto(string texto);

		List<Planta> BuscarPorTipo(int idTipo);

		List<Planta> BuscarPorAmbiente(int idAmbiente);

		List<Planta> BuscarPorAltura(int altura, string criterio);

		public bool NombreCientificoExiste(string nombreCentifico);

		FichaCuidado VerCuidados(int id);

		public bool ExistePlanta(int idPlanta);

	}

}

