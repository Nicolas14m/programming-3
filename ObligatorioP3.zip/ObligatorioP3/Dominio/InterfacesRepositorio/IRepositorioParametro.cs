using Dominio.EntidadesNegocio;
using Dominio.Interfaces;

namespace Dominio.Interfaces
{
	public interface IRepositorioParametro : IRepositorio<Parametro>
	{

		public decimal GetValorParametro(string nomParametro);


	}

}

