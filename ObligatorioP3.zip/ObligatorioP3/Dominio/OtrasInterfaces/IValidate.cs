﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio.OtrasInterfaces
{
    public interface IValidate
    {
        bool Validar();
    }
}
