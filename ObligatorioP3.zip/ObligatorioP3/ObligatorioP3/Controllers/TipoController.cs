﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ObligatorioP3.Controllers
{
    public class TipoController : Controller
    {

        public IManejadorTipos ManejadorTipos { get; set; }


        public TipoController(IManejadorTipos manejadorTipos)
        {
            ManejadorTipos = manejadorTipos;
        }

        
        // Mostrar todos los Tipos
        public ActionResult Index()
        {

            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {
                IEnumerable<TipoPlanta> todosLosTipos = ManejadorTipos.TraerTipos();
                return View(todosLosTipos);

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }


        // Crear Tipo
        public ActionResult Create()
        {
            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {
                int minDesc = (int) ManejadorTipos.ObtenerValorParametro("MinDescTipo");
                int maxDesc = (int)ManejadorTipos.ObtenerValorParametro("MaxDescTipo");

                ViewBag.ParametroMinDescTipo = minDesc;
                ViewBag.ParametroMaxDescTipo = maxDesc;


                TipoPlanta t = new TipoPlanta();
                return View(t);

            }
            else {
                return RedirectToAction("Index", "Home");
            }

        }

        // Crear Tipo POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TipoPlanta tipoPlanta)
        {
            try
            {
                int minDescTipo = (int)ManejadorTipos.ObtenerValorParametro("MinDescTipo");
                int maxDescTipo = (int)ManejadorTipos.ObtenerValorParametro("MaxDescTipo");

                ViewBag.ParametroMinDescTipo = minDescTipo;
                ViewBag.ParametroMaxDescTipo = maxDescTipo;

                if (!ManejadorTipos.TipoYaExiste(tipoPlanta.Nombre))
                {

                    if (tipoPlanta.Descripcion.Trim().Length >= minDescTipo && tipoPlanta.Descripcion.Trim().Length <= maxDescTipo && ModelState.IsValid)
                    {

                        bool resultado = ManejadorTipos.AgregarTipo(tipoPlanta);

                        if (resultado)
                        {
                            return RedirectToAction("Index", "Tipo");
                        }
                        else
                        {
                            ViewBag.Error = "No se pudo ingresar el tipo, verifique los datos.";
                            return View(tipoPlanta);
                        }

                    }
                    else {
                        ViewBag.Error = $"La descripción debe estar dentro de {(int) minDescTipo} y {(int) maxDescTipo} caracteres.";
                        return View(tipoPlanta);

                    }

                }
                else {

                    ViewBag.Error = "Ese tipo de planta ya existe en la base de datos, pruebe otro.";
                    return View(tipoPlanta);
                }


            }
            catch
            {
                ViewBag.Error = "Error con la base de datos.";
                return View(tipoPlanta);
            }

        }

        // Editar Tipo 
        public ActionResult Edit(int id)
        {

            int minDescTipo = (int)ManejadorTipos.ObtenerValorParametro("MinDescTipo");
            int maxDescTipo = (int)ManejadorTipos.ObtenerValorParametro("MaxDescTipo");

            ViewBag.ParametroMinDescTipo = minDescTipo;
            ViewBag.ParametroMaxDescTipo = maxDescTipo;

            TipoPlanta tipoBuscado = ManejadorTipos.BuscarTipoPorId(id);
            return View(tipoBuscado);
        }

        // Editar Tipo POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TipoPlanta tipoPlanta)
        {

            try
            {

                int minDescTipo = (int)ManejadorTipos.ObtenerValorParametro("MinDescTipo");
                int maxDescTipo = (int)ManejadorTipos.ObtenerValorParametro("MaxDescTipo");

                ViewBag.ParametroMinDescTipo = minDescTipo;
                ViewBag.ParametroMaxDescTipo = maxDescTipo;

                if (tipoPlanta.Descripcion.Trim().Length >= minDescTipo && tipoPlanta.Descripcion.Trim().Length <= maxDescTipo)
                {

                    bool resultado = ManejadorTipos.ActualizarTipo(tipoPlanta);

                    if (resultado)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    else
                    {
                        ViewBag.Error = "Error al actualizar este tipo de planta";
                        return View();
                    }

                }
                else {
                    ViewBag.Error = $"La descripción debe estar dentro de {minDescTipo} y {maxDescTipo} caracteres.";
                    return View();

                }

            }
            catch
            {
                ViewBag.Error = "Error al actualizar este tipo de planta";
                return View();
            }
        }

        // Eliminar Tipo
        public ActionResult Delete(int id)
        {
            TipoPlanta tipoBuscado = ManejadorTipos.BuscarTipoPorId(id);

            return View(tipoBuscado);
        }

        // Eliminar Tipo POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(TipoPlanta tipoPlanta)
        {

            TipoPlanta tipoBuscado = ManejadorTipos.BuscarTipoPorId(tipoPlanta.Id);

            try
            {
                if (!ManejadorTipos.TipoEnUso(tipoPlanta.Id))
                {
                    bool resultado = ManejadorTipos.BajaTipo(tipoPlanta.Id);

                    if (resultado)
                    {

                        return RedirectToAction(nameof(Index));
                    }
                    else
                    {
                        ViewBag.Error = "No se pudo eliminar el tipo.";
                        return View(tipoBuscado);
                    }

                }
                else {
                    ViewBag.Error = "No se pudo eliminar el tipo, actualmente esta en uso en una o varias plantas.";
                    return View(tipoBuscado);
                }

            }
            catch
            {
                ViewBag.Error = "Error con la base de datos.";
                return View(tipoBuscado);
            }
        }


        // Buscar por Nombre
        public ActionResult BuscarTipoPorNombre()
        {
            return View();
        }

        // Buscar por Nombre POST

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BuscarTipoPorNombre(string nombre)
        {
            IEnumerable<TipoPlanta> tiposBuscados = ManejadorTipos.BuscarTipoPorNombre(nombre);
            return View(tiposBuscados);
        }


    }



    

}
