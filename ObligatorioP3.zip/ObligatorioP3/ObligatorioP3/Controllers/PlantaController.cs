﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ObligatorioP3.Models;
using System.Collections.Generic;
using System.IO;
namespace ObligatorioP3.Controllers
{
    public class PlantaController : Controller
    {


        public IManejadorPlantas ManejadorPlantas { get; set; }

        public IWebHostEnvironment WhEnviroment { get; set; }

        public PlantaController(IManejadorPlantas manejadorPlantas, IWebHostEnvironment whEnviroment )
        {
            ManejadorPlantas = manejadorPlantas;
            WhEnviroment = whEnviroment;
        }


        // Ver todas las plantas
        public ActionResult Index()
        {


            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {
                IEnumerable<Planta> todasLasPlantas = ManejadorPlantas.TraerTodasLasPlantas();
                return View(todasLasPlantas);

            }
            else { 
                return RedirectToAction("Index", "Home");
            }
        }


        // GET: PlantaController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // Agregar Planta GET
        public ActionResult Create()
        {
            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {

                ViewBag.ParametroMinDescPlanta =(int) ManejadorPlantas.ObtenerValorParametro("MinDescPlanta");
                ViewBag.ParametroMaxDescPlanta = (int) ManejadorPlantas.ObtenerValorParametro("MaxDescPlanta");

                ViewModel_Planta VMPlanta = new ViewModel_Planta();

                VMPlanta.Ambientes = ManejadorPlantas.TraerTodosLosAmbientes();
                VMPlanta.TiposIluminacion = ManejadorPlantas.TraerTodosLosTiposIluminacion();
                VMPlanta.TiposPlanta = ManejadorPlantas.TraerTodosLosTiposDePlanta();

                return View(VMPlanta);


            }
            else {

                return RedirectToAction("Index", "Home");
            }
            

        }

        // // Agregar Planta POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ViewModel_Planta VMPlanta)
        {
            // Buscamos las listas nuevamente por si hay un error y vuelve a la view del formulario
            VMPlanta.Ambientes = ManejadorPlantas.TraerTodosLosAmbientes();
            VMPlanta.TiposIluminacion = ManejadorPlantas.TraerTodosLosTiposIluminacion();
            VMPlanta.TiposPlanta = ManejadorPlantas.TraerTodosLosTiposDePlanta();

            ViewBag.ParametroMinDescPlanta = (int) ManejadorPlantas.ObtenerValorParametro("MinDescPlanta");
            ViewBag.ParametroMaxDescPlanta = (int) ManejadorPlantas.ObtenerValorParametro("MaxDescPlanta");

            try
            {

                if (!ManejadorPlantas.NombreCientificoExiste(VMPlanta.Planta.NombreCientifico))
                {

                    int minDescPlanta =(int) ManejadorPlantas.ObtenerValorParametro("MinDescPlanta");
                    int maxDescPlanta = (int)ManejadorPlantas.ObtenerValorParametro("MaxDescPlanta");



                    if (VMPlanta.Planta.Descripcion.Trim().Length >= minDescPlanta && VMPlanta.Planta.Descripcion.Trim().Length <= maxDescPlanta)
                    {

                        string nomArchivoFoto = VMPlanta.Imagen.FileName;

                        string extension = Path.GetExtension(nomArchivoFoto);

                        VMPlanta.Planta.Foto = ManejadorPlantas.GenerarNombreFotoPlanta(VMPlanta.Planta.NombreCientifico, extension);

                        bool resultado = ManejadorPlantas.AgregarPlanta(VMPlanta.Planta, VMPlanta.IdTipoPlantaSeleccionado, VMPlanta.IdTipoIluminacionSeleccionado, VMPlanta.IdAmbienteSeleccionado, VMPlanta.FichaCuidado);


                        if (resultado)
                        {
                            // Obentemos la ruta a la raiz de la app
                            string rutaRaizApp = WhEnviroment.WebRootPath;

                            // Armamos una ruta completa que combina el nombre de la foto

                            rutaRaizApp = Path.Combine(rutaRaizApp, "img");

                            string rutaCompleta = Path.Combine(rutaRaizApp, VMPlanta.Planta.Foto);


                            // Creamos un filestream que se usa para guardar la imagen
                            FileStream stream = new FileStream(rutaCompleta, FileMode.Create);

                            VMPlanta.Imagen.CopyTo(stream);

                            return RedirectToAction("Index", "Planta");

                        }

                        else
                        {
                            ViewBag.Error = "Ha ocurrido un error, verifique los datos.";
                            return View(VMPlanta);
                        }
                    }

                    else
                    {
                        ViewBag.Error = $"La descripción debe estar dentro de {minDescPlanta} y {maxDescPlanta} caracteres.";
                        return View(VMPlanta);
                    }

                }
                else {
                    ViewBag.Error = "Ese nombre científico ya existe en la base de datos, pruebe otro.";
                    return View(VMPlanta);
                }

            }
            catch 
            {
                ViewBag.Error = "Ha ocurrido un error con la base de datos.";
                return View(VMPlanta);

            }

        }



        // GET: PlantaController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PlantaController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PlantaController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PlantaController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public ActionResult VerFicha(int id) {

            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {
                FichaCuidado fichaBuscada = ManejadorPlantas.TraerFichaPorId(id);
                return View(fichaBuscada);


            }
            else {

                return RedirectToAction("Index", "Home");


            }

        }

        // **** BUSQUEDAS ****
        public ActionResult BuscarPorNombre()
        {
            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {
                return View();

            }
            else { 
                return RedirectToAction("Index", "Home");

            }

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BuscarPorNombre(string textoBusqueda)
        {

            IEnumerable<Planta> plantasBusquedas = ManejadorPlantas.BuscarPlantaPorNombre(textoBusqueda);
            return View(plantasBusquedas);
        }

        public ActionResult BuscarPorTipo()
        {
            if (HttpContext.Session.GetString("logueadoEmail") != null)
            { 
                IEnumerable<TipoPlanta> todosLosTipos =  ManejadorPlantas.TraerTodosLosTiposDePlanta();
                ViewBag.todosLosTipos = todosLosTipos;
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");

            }

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BuscarPorTipo(int IdTipoPlantaSeleccionado)
        {
            IEnumerable < Planta > plantasBuscadas = ManejadorPlantas.BuscarPlantasPorTipo(IdTipoPlantaSeleccionado);
            IEnumerable<TipoPlanta> todosLosTipos = ManejadorPlantas.TraerTodosLosTiposDePlanta();
            ViewBag.todosLosTipos = todosLosTipos;
            return View(plantasBuscadas);
        }

        public ActionResult BuscarPorAmbiente()
        {

            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {

                IEnumerable<Ambiente> todosLosAmbientes = ManejadorPlantas.TraerTodosLosAmbientes();
                ViewBag.todosLosAmbientes = todosLosAmbientes;
                return View();

            }
            else { 
            
                return RedirectToAction("Index", "Home");

            }

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BuscarPorAmbiente(int IdAmbienteSeleccionado)
        {
            IEnumerable<Planta> plantasBuscadas = ManejadorPlantas.BuscarPlantasPorAmbiente(IdAmbienteSeleccionado);


            IEnumerable<Ambiente> todosLosAmbientes = ManejadorPlantas.TraerTodosLosAmbientes();
            ViewBag.todosLosAmbientes = todosLosAmbientes;


            return View(plantasBuscadas);
        }

        public ActionResult BuscarPorAltura()
        {
            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {
                return View();

            }
            else { 
                return RedirectToAction("Index", "Home");
            }

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BuscarPorAltura(int altura, string criterio)
        {
            IEnumerable<Planta> plantas = ManejadorPlantas.BuscarPlantasPorAltura(altura, criterio);
            ViewBag.altura = altura;
            return View(plantas);
        }

    }
}
