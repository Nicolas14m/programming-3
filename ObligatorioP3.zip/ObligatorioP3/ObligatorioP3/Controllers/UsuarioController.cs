﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ObligatorioP3.Controllers
{
    public class UsuarioController : Controller
    {
        
        public IManejadorUsuarios ManejadorUsuarios { get; set; }


        public UsuarioController(IManejadorUsuarios manejadorUsuarios)
        {
            ManejadorUsuarios = manejadorUsuarios;
        }

      
        public ActionResult Login()
        {
            Usuario u = new Usuario();


            if (HttpContext.Session.GetString("logueadoEmail") == null)
            {
                return View(u);

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Usuario u)
        {
            try
            {
                bool resultado = ManejadorUsuarios.Login(u.Email, u.Password);

                if (resultado)
                {
                    HttpContext.Session.SetInt32("logueadoId", u.Id);
                    HttpContext.Session.SetString("logueadoEmail", u.Email);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ViewBag.Error = "Email o Contraseña incorrectos.";
                    return View(u);
                }
            }
            catch
            {
                ViewBag.Error = "Email o Contraseña incorrectos.";
                return View(u);
            }
        }

        public IActionResult Logout()
        {
            if (HttpContext.Session.GetString("logueadoEmail") != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpPost]
        public IActionResult Logout(string _)
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }


        public ActionResult Registro()
        {

            Usuario u = new Usuario();

            if (HttpContext.Session.GetString("logueadoEmail") == null)
            {

                return View(u);

            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // Alta Usuario
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Registro(Usuario u)
        {
           
            try
            {
                bool resultado = ManejadorUsuarios.AgregarUsuario(u);

                if (resultado) {

                    Login(u);
                    return RedirectToAction("Index", "Home");

                }

                ViewBag.ResultadoRegistro = "Error al registrarse! Verifique datos";
                return View();

            }
            catch
            {
                ViewBag.ResultadoRegistro = "Error con la base de datos! Pruebe otro email.";
                return View();
            }
        }

        public ActionResult PrecargaUsr()
        {
            Usuario u1 = new Usuario() { Email = "admin6@gmail.com", Password = "Password1234" };
            Usuario u2 = new Usuario() { Email = "admin7@gmail.com", Password = "Password5678" };
            Usuario u3 = new Usuario() { Email = "admin8@gmail.com", Password = "Password9XXX" };

            if (u1.Validar() && u2.Validar() && u3.Validar())
            {
                if (!ManejadorUsuarios.ExisteEmail(u1.Email) && !ManejadorUsuarios.ExisteEmail(u2.Email) && !ManejadorUsuarios.ExisteEmail(u3.Email))
                {
                    try
                    {
                        bool resultado1 = ManejadorUsuarios.AgregarUsuario(u1);
                        bool resultado2 = ManejadorUsuarios.AgregarUsuario(u2);
                        bool resultado3 = ManejadorUsuarios.AgregarUsuario(u3);

                        if (resultado1 && resultado2 && resultado3)
                        {
                            List<Usuario> usuariosAgregados = new List<Usuario>();

                            usuariosAgregados.Add(u1);
                            usuariosAgregados.Add(u2);
                            usuariosAgregados.Add(u3);

                            ViewBag.ExitoRegistro = "Se registraron 3 usuarios con éxito.";
                            return View(usuariosAgregados);

                        }


                        ViewBag.ErrorRegistro = "Error al registrar. Verifique datos";
                        return View();
                    }
                    catch
                    {


                        ViewBag.ErrorRegistro = "Error con la base de datos!";
                        return View();
                    }

                }
                else {
                    ViewBag.ErrorRegistro = "Error, ya se precargaron estos usuarios!";
                    return View();

                }
            }
            else {
                ViewBag.ErrorRegistro = "Error al agregar usuarios precargados.";
                                    return View();

            }

        }
        public ActionResult Index()
        {
            return View();
        }

        // GET: UsuarioController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: UsuarioController/Create
        

        // GET: UsuarioController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: UsuarioController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UsuarioController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UsuarioController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
