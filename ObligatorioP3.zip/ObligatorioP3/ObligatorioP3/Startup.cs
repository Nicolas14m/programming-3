using CasosUso.InterfacesManejadores;
using CasosUso.Manejadores;
using Dominio.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Repositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace ObligatorioP3
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            services.AddSession(); // Agregamos AddSession

            // Inyeccion de dependencias para los manejadores y repositorio de Usuarios.
            services.AddScoped<IManejadorUsuarios, ManejadorUsuarios>();
            services.AddScoped<IRepositorioUsuario, RepositorioUsuarios>();

            // Inyeccion de dependencias para los manejadores y repositorio de Tipos de plantas.
            services.AddScoped<IManejadorTipos, ManejadorTipos>();
            services.AddScoped<IRepositorioTipo, RepositorioTipos>();
            services.AddScoped<IRepositorioCompra, RepositorioCompras>();
            services.AddScoped<IManejadorCompras, ManejadorCompras>();

            services.AddScoped<IManejadorPlantas, ManejadorPlantas>();
            services.AddScoped<IRepositorioAmbiente, RepositorioAmbientes>();
            services.AddScoped<IRepositorioTipoIluminacion, RepositorioTiposIluminacion>();
            services.AddScoped<IRepositorioPlanta, RepositorioPlantas>();
            services.AddScoped<IRepositorioParametro, RepositorioParametros>();

            services.AddDbContext<ViveroContext>
                (opciones => opciones
                            .UseSqlServer(Configuration.GetConnectionString("miConexionLocal")));

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseSession(); // Se agrega UseSession
            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
