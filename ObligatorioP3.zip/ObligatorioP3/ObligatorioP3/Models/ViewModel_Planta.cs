﻿using Dominio.EntidadesNegocio;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace ObligatorioP3.Models
{
    public class ViewModel_Planta
    {
        public Planta Planta { get; set; }
        public IEnumerable<Ambiente> Ambientes { get; set; }
        public IEnumerable<TipoIluminacion> TiposIluminacion { get; set; }
        public IEnumerable<TipoPlanta> TiposPlanta { get; set; }
        public IFormFile Imagen { get; set; }
        public FichaCuidado FichaCuidado { get; set; }

        public int IdAmbienteSeleccionado { get; set; }

        public int IdTipoIluminacionSeleccionado { get; set; }

        public int IdTipoPlantaSeleccionado { get; set; }
    }
}
