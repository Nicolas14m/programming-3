﻿using Dominio.EntidadesNegocio;
using Repositorios;
using System;

namespace TestConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
