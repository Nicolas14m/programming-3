﻿using Dominio.EntidadesNegocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasosUso.InterfacesManejadores
{
    public interface IManejadorCompras
    {

        bool AgregarCompra(Compra compra);
        IEnumerable<Compra> ObtenerComprasPorTipoPlanta(string tipo);
        public decimal ObtenerValorParametro(string nombreParametro);
        public bool ExistePlanta(int idPlanta);
        public bool ExisteTipo(int idTipo);

    }
}
