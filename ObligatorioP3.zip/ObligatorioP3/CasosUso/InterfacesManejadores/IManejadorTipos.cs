﻿using Dominio.EntidadesNegocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasosUso.InterfacesManejadores
{
    public interface IManejadorTipos
    {

        bool AgregarTipo(TipoPlanta t);
        bool BajaTipo(int id);
        IEnumerable<TipoPlanta> TraerTipos();
        IEnumerable<TipoPlanta> BuscarTipoPorNombre(string nombre);

        TipoPlanta BuscarTipoPorId(int Id);
        bool TipoYaExiste(string nombreTipo);

        bool ActualizarTipo(TipoPlanta t);
        decimal ObtenerValorParametro(string nombreParametro);

        bool TipoEnUso(int idTipo);   



    }
}
