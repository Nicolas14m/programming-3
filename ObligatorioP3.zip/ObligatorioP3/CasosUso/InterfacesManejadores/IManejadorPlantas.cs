﻿using Dominio.EntidadesNegocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasosUso.InterfacesManejadores
{
    public interface IManejadorPlantas
    {

        bool AgregarPlanta(Planta p, int idTipoPlanta, int idTipoIluminacion, int idAmbiente, FichaCuidado fichaCuidado);
        bool BajaPlanta(int id);
        bool ActualizarPlanta(Planta p);
        FichaCuidado TraerFichaPorId(int id);
        IEnumerable<Ambiente> TraerTodosLosAmbientes();
        IEnumerable<TipoIluminacion> TraerTodosLosTiposIluminacion();
        string GenerarNombreFotoPlanta(string nombreCientifico, string ext);
        IEnumerable<TipoPlanta> TraerTodosLosTiposDePlanta();
        bool NombreCientificoExiste(string nombreCientifico);

        // Busquedas
        IEnumerable<Planta> BuscarPlantaPorNombre(string nombre);

        IEnumerable<Planta> BuscarPlantasPorTipo(int idTipo);

        IEnumerable<Planta> BuscarPlantasPorAmbiente(int idAmbiente);

        IEnumerable<Planta> BuscarPlantasPorAltura(int altura, string criterio);

        decimal ObtenerValorParametro(string nombreParametro);

        Planta BuscarPlantaPorId(int id);
        IEnumerable<Planta> TraerTodasLasPlantas();

    }
}
