﻿using Dominio.EntidadesNegocio;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasosUso.InterfacesManejadores
{
    public interface IManejadorUsuarios
    {

        bool AgregarUsuario(Usuario u);
        bool BajaUsuario(int id);
        IEnumerable<Usuario> TraerUsuarios();
        Usuario BuscarUsuarioPorId(int id);
        bool ActualizarUsuario(Usuario u);

        bool Login(string email, string password);

        bool Logout();

        bool ExisteEmail(string email);

    }
}
