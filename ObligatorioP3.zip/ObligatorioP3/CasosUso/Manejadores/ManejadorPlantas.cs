﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CasosUso.Manejadores
{
    public class ManejadorPlantas : IManejadorPlantas
    {

        public IRepositorioAmbiente RepoAmbientes { get; set; }

        public IRepositorioTipoIluminacion RepoTiposIluminacion { get; set; }

        public IRepositorioTipo RepoTipoPlanta { get; set; }

        public IRepositorioPlanta RepoPlantas { get; set; }

        public IRepositorioParametro RepoParametros { get; set; }


        public ManejadorPlantas(IRepositorioAmbiente repoAmbientes, IRepositorioTipoIluminacion repoTiposIluminacion, IRepositorioTipo repoTipoPlanta, IRepositorioPlanta repoPlantas, IRepositorioParametro repoParametros
            )
        {
            RepoAmbientes = repoAmbientes;
            RepoTiposIluminacion = repoTiposIluminacion;
            RepoTipoPlanta = repoTipoPlanta;
            RepoPlantas = repoPlantas;
            RepoParametros = repoParametros;
        }

        public IEnumerable<Ambiente> TraerTodosLosAmbientes()
        {
           return RepoAmbientes.FindAll();
        }

        public IEnumerable<TipoIluminacion> TraerTodosLosTiposIluminacion()
        {
            return RepoTiposIluminacion.FindAll();
        }

        public IEnumerable<TipoPlanta> TraerTodosLosTiposDePlanta()
        {
            return RepoTipoPlanta.FindAll();
        }

        public bool ActualizarPlanta(Planta p)
        {
            throw new NotImplementedException();
        }

        public bool AgregarPlanta(Planta p, int idTipoPlanta, int idTipoIluminacion, int idAmbiente, FichaCuidado fichaCuidado)
        {

            bool resultado = false;

            TipoPlanta tipoPlanta = RepoTipoPlanta.FindById(idTipoPlanta);

            if (tipoPlanta != null) { 
                
                TipoIluminacion tipoIluminacion = RepoTiposIluminacion.FindById(idTipoIluminacion);

                if (tipoIluminacion != null) {

                    fichaCuidado.TipoIluminacion = tipoIluminacion;
                
                    Ambiente ambiente = RepoAmbientes.FindById(idAmbiente);


                    if (ambiente != null) { 

                        p.Ambiente = ambiente;
                        p.FichaCuidados = fichaCuidado;
                        p.Tipo = tipoPlanta;
                        resultado = RepoPlantas.Add(p);
                    }
                
                }
            
            }

            return resultado;
        }

        public bool BajaPlanta(int id)
        {
            throw new NotImplementedException();
        }

        public Planta BuscarPlantaPorId(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Planta> TraerTodasLasPlantas()
        {
           return RepoPlantas.FindAll();
        }

        
        public string GenerarNombreFotoPlanta(string nombreCientifico, string ext)
        {
            return nombreCientifico.Replace(" ", "_") + "_001" + ext;
        }

        public FichaCuidado TraerFichaPorId(int id)
        {
           return RepoPlantas.VerCuidados(id);
        }

        public IEnumerable<Planta> BuscarPlantaPorNombre(string nombre)
        {
           return RepoPlantas.BuscarPorTexto(nombre);
        }

        public IEnumerable<Planta> BuscarPlantasPorTipo(int idTipo)
        {
           return  RepoPlantas.BuscarPorTipo(idTipo);
        }

        public IEnumerable<Planta> BuscarPlantasPorAmbiente(int idAmbiente)
        {
            return RepoPlantas.BuscarPorAmbiente(idAmbiente);
        }

        public IEnumerable<Planta> BuscarPlantasPorAltura(int altura, string criterio)
        {
            return RepoPlantas.BuscarPorAltura(altura, criterio);
        }

        public bool NombreCientificoExiste(string nombreCientifico)
        {
            return RepoPlantas.NombreCientificoExiste(nombreCientifico);
        }

        public decimal ObtenerValorParametro(string nombreParametro)
        {
           return RepoParametros.GetValorParametro(nombreParametro);
        }
    }


}
