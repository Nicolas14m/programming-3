﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasosUso.Manejadores
{
    public class ManejadorUsuarios : IManejadorUsuarios
    {

        public IRepositorioUsuario RepoUsuarios { get; set; }


        public ManejadorUsuarios(IRepositorioUsuario repoUsuarios)
        {
            RepoUsuarios = repoUsuarios;
        }



        public bool ActualizarUsuario(Usuario u)
        {
            throw new NotImplementedException();
        }

        public bool AgregarUsuario(Usuario u)
        {
            return RepoUsuarios.Add(u);
        }

        public bool BajaUsuario(int id)
        {
            throw new NotImplementedException();
        }

        public Usuario BuscarUsuarioPorId(int id)
        {
            throw new NotImplementedException();
        }

        public bool Login(string email, string password)
        {
           return RepoUsuarios.Login(email, password);    
        }

        public bool Logout()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Usuario> TraerUsuarios()
        {
            throw new NotImplementedException();
        }

        public bool ExisteEmail(string email)
        {
            return RepoUsuarios.ExisteEmail(email);
        }
    }
}
