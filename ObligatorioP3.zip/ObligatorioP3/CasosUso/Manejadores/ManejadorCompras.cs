﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasosUso.Manejadores
{
    public class ManejadorCompras : IManejadorCompras
    {

        public IRepositorioCompra RepoCompras { get; set; }

        public IRepositorioParametro RepoParametros { get; set; }

        public IRepositorioPlanta RepoPlantas { get; set; }

        public IRepositorioTipo RepoTipos { get; set; }



        public ManejadorCompras(IRepositorioCompra repoCompras, IRepositorioParametro repoParametros, IRepositorioPlanta repoPlantas, IRepositorioTipo repoTipos)
        {
            RepoCompras = repoCompras;
            RepoParametros = repoParametros;
            RepoPlantas = repoPlantas;
            RepoTipos = repoTipos;
        }


        public bool AgregarCompra(Compra compra)
        {
            return RepoCompras.Add(compra);
        }

        public IEnumerable<Compra> ObtenerComprasPorTipoPlanta(string tipo)
        {
            return RepoCompras.ObtenerComprasPorTipoPlanta(tipo);
        }

        public decimal ObtenerValorParametro(string nombreParametro)
        {
            return RepoParametros.GetValorParametro(nombreParametro);
        }

        public bool ExistePlanta(int idPlanta)
        {
            return RepoPlantas.ExistePlanta(idPlanta);
        }

        public bool ExisteTipo(int idTipo)
        {
            return RepoTipos.ExisteTipo(idTipo);
        }
    }
}
