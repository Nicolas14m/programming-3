﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasosUso.Manejadores
{
    public class ManejadorTipos : IManejadorTipos
    {
        public IRepositorioTipo RepoTipos { get; set; }

        public IRepositorioParametro RepoParametros { get; set; }


        public ManejadorTipos(IRepositorioTipo repoTipos, IRepositorioParametro repoParametros)
        {
            RepoTipos = repoTipos;
            RepoParametros = repoParametros;
        }
        

        public bool AgregarTipo(TipoPlanta t)
        {
           return RepoTipos.Add(t);
        }

        public bool BajaTipo(int id)
        {
            return RepoTipos.Remove(id);
        }

        public bool ActualizarTipo(TipoPlanta t)
        {
            return RepoTipos.Update(t);
        }

        public TipoPlanta BuscarTipoPorId(int Id)
        {
            return RepoTipos.FindById(Id);
        }

        public IEnumerable<TipoPlanta> TraerTipos()
        {
            return RepoTipos.FindAll();
        }

        public IEnumerable<TipoPlanta> BuscarTipoPorNombre(string nombre)
        {
            return RepoTipos.EncontrarPorNombre(nombre);
        }

        public bool TipoYaExiste(string nombreTipo)
        {
            return RepoTipos.TipoYaExiste(nombreTipo);
        }


        public decimal ObtenerValorParametro(string nombreParametro)
        {
            return RepoParametros.GetValorParametro(nombreParametro);
        }

        public bool TipoEnUso(int idTipo)
        {
            return RepoTipos.TipoEnUso(idTipo);
        }
    }
}
