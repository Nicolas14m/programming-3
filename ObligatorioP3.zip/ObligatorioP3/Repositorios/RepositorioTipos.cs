﻿using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Repositorios
{
    public class RepositorioTipos : IRepositorioTipo
    {

        public ViveroContext Contexto { get; set; }

        public RepositorioTipos(ViveroContext ctx)
        {
            Contexto = ctx;
        }

        public bool Add(TipoPlanta tipoPlanta)
        {
            bool resultado = false;

            if (tipoPlanta != null && tipoPlanta.Validar())
            {
                Contexto.TiposPlanta.Add(tipoPlanta);
                return Contexto.SaveChanges() >= 1;
            }

            return resultado;
        }

        public IEnumerable<TipoPlanta> EncontrarPorNombre(string nombre)
        {
            return Contexto.TiposPlanta.Where(tipo => tipo.Nombre == nombre)
                            .ToList();
        }

        public IEnumerable<TipoPlanta> FindAll()
        {
            return Contexto.TiposPlanta.ToList();
        }

        public TipoPlanta FindById(int id)
        {
            return Contexto.TiposPlanta.Find(id);
        }

        public bool Remove(int id)
        {

            TipoPlanta p = FindById(id);

            if (p != null) {
                Contexto.TiposPlanta.Remove(p);
                return Contexto.SaveChanges() >= 1;
            }

            return false;
        }

        public bool TipoEnUso(int idTipo)
        {
            
            return Contexto.Plantas.Any(p => p.Tipo.Id == idTipo);
            
        }

        public bool TipoYaExiste(string nombreTipo)
        {

            return Contexto.TiposPlanta.Any(t => t.Nombre == nombreTipo);
        }

        public bool Update(TipoPlanta tipoPlanta)
        {
            Contexto.TiposPlanta.Update(tipoPlanta);
            return Contexto.SaveChanges() >= 1;

        }

        public bool ExisteTipo(int idTipo)
        {
            return Contexto.TiposPlanta.Any(t => t.Id == idTipo);
        }
    }
}
