﻿using System;
using System.Collections.Generic;
using System.Text;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using Microsoft.Data.SqlClient;
using System.Linq;
namespace Repositorios
{
    public class RepositorioTiposIluminacion : IRepositorioTipoIluminacion
    {

        public ViveroContext Contexto { get; set; }

        public RepositorioTiposIluminacion(ViveroContext ctx)
        {
            Contexto = ctx;
        }


        public TipoIluminacion FindById(int id)
        {
            return Contexto.TiposIluminacion.Find(id);
        }

        public IEnumerable<TipoIluminacion> FindAll()
        {
            return Contexto.TiposIluminacion.ToList();

        }

        public bool Add(TipoIluminacion obj)
        {
            throw new NotImplementedException();
        }

        public bool Remove(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(TipoIluminacion obj)
        {
            throw new NotImplementedException();
        }
    }
}
