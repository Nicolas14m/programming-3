﻿using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Repositorios
{
    public class RepositorioCompras : IRepositorioCompra
    {

        public ViveroContext Contexto { get; set; }

        public RepositorioCompras(ViveroContext ctx)
        {
            Contexto = ctx;
        }

        public bool Add(Compra compra)
        {

            bool resultado = false;

            if (compra != null) {
                Contexto.Compras.Add(compra);
                resultado = Contexto.SaveChanges() >= 1;
            }

            return resultado;
        }

        public IEnumerable<Compra> FindAll()
        {
            throw new NotImplementedException();
        }

        public Compra FindById(int id)
        {
            throw new NotImplementedException();
        }

        public bool Remove(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(Compra obj)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Compra> ObtenerComprasPorTipoPlanta(string tipo)
        {
            return Contexto.Compras.Include(c => c.ItemsCompras)
                                    .ThenInclude(ic => ic.Planta)
                                    .Where(c => c.ItemsCompras
                                    .Any(ic => ic.Planta.Tipo.Nombre == tipo))
                                    .ToList();
        }
    }
}
