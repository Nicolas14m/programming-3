﻿using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Repositorios
{
    public class RepositorioParametros : IRepositorioParametro
    {

        public ViveroContext Contexto { get; set; }

        public RepositorioParametros(ViveroContext ctx)
        {
            Contexto = ctx;
        }

        public decimal GetValorParametro(string nomParametro)
        {
              return Contexto.Parametros.Where(p => p.Nombre == nomParametro).Select(v => v.Valor).SingleOrDefault();
        }

        public bool Add(Parametro obj)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Parametro> FindAll()
        {
            throw new NotImplementedException();
        }

        public Parametro FindById(int id)
        {
            throw new NotImplementedException();
        }
        public bool Remove(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(Parametro obj)
        {
            throw new NotImplementedException();
        }



       
    }
}
