﻿using System;
using System.Collections.Generic;
using System.Text;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using Microsoft.Data.SqlClient;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Repositorios
{
    public class RepositorioPlantas : IRepositorioPlanta
    {
        public ViveroContext Contexto { get; set; }

        public RepositorioPlantas(ViveroContext ctx)
        {
            Contexto = ctx;
        }

        public bool Add(Planta planta)
        {
            bool resultado = false;

            if (planta != null && planta.Validar())
            {
                Contexto.Plantas.Add(planta);
                resultado = Contexto.SaveChanges() >= 1;
            }

            return resultado;
        }

        public IEnumerable<Planta> FindAll()
        {
            return Contexto.Plantas.Include(p => p.Ambiente)
                                    .Include(p => p.Tipo)
                                    .Include(p => p.FichaCuidados)
                                    .ToList();
        }

        // *********** Busquedas ***********

        public List<Planta> BuscarPorAmbiente(int idAmbiente)
        {
            return Contexto.Plantas.Include(p => p.Ambiente)
                                    .Include(p => p.Tipo)
                                    .Include(p => p.FichaCuidados)
                                    .Where(p => p.Ambiente.Id == idAmbiente)
                                    .ToList();
        }

        public List<Planta> BuscarPorAltura(int altura, string criterio)
        {
            if (criterio == "mayor")
            {
                return Contexto.Plantas.Include(p => p.Ambiente)
                                     .Include(p => p.Tipo)
                                     .Include(p => p.FichaCuidados)
                                     .Where(p => p.AlturaMaxima >= altura)
                                     .ToList();
            }

            return Contexto.Plantas.Include(p => p.Ambiente)
                                         .Include(p => p.Tipo)
                                         .Include(p => p.FichaCuidados)
                                         .Where(p => p.AlturaMaxima < altura)
                                         .ToList();
        }

        public List<Planta> BuscarPorTexto(string texto)
        {
            return Contexto.Plantas.Include(p => p.Ambiente)
                                    .Include(p => p.Tipo)
                                    .Include(p => p.FichaCuidados)
                                    .Where(p => p.NombreCientifico
                                    .Contains(texto) || p.NombreVulgar
                                    .Contains(texto))
                                    .ToList();

        }

        public List<Planta> BuscarPorTipo(int idTipo)
        {
            return Contexto.Plantas.Include(p => p.Ambiente)
                                    .Include(p => p.Tipo)
                                    .Include(p => p.FichaCuidados)
                                    .Where(p => p.Tipo.Id == idTipo)
                                    .ToList();
        }

        public bool NombreCientificoExiste(string nombreCentifico)
        {
            return Contexto.Plantas.Any(p => p.NombreCientifico == nombreCentifico);
        }

        public FichaCuidado VerCuidados(int id)
        {
            return Contexto.Plantas.Where(p => p.FichaCuidados.Id == id)
                                   .Include(p => p.FichaCuidados.TipoIluminacion)
                                   .Select(p => p.FichaCuidados)
                                   .SingleOrDefault();
        }

        public Planta FindById(int id)
        {
            return Contexto.Plantas.Find(id);
        }

        

        public bool Remove(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(Planta obj)
        {
            throw new NotImplementedException();
        }

        public bool ExistePlanta(int idPlanta)
        {
            return Contexto.Plantas.Any(p => p.Id == idPlanta);

        }
    }
}
