﻿using System;
using System.Collections.Generic;
using System.Text;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Linq;

namespace Repositorios
{
    public class RepositorioUsuarios : IRepositorioUsuario
    {

        public ViveroContext Contexto { get; set; }

        public RepositorioUsuarios(ViveroContext ctx)
        {
            Contexto = ctx;
        }

        public bool Add(Usuario u)
        {
            bool resultado = false;

            if (u != null && u.Validar())
            {
                Contexto.Usuarios.Add(u);
                return Contexto.SaveChanges() >= 1;
            }

            return resultado;

        }

        public bool Login(string email, string password)
        {
            Usuario u = Contexto.Usuarios.Where(u => u.Email == email && u.Password == password).SingleOrDefault();
            return u != null;
        }

        public bool Logout()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Usuario> FindAll()
        {
            throw new NotImplementedException();
        }

        public Usuario FindById(int id)
        {
            throw new NotImplementedException();
        }


        public bool Remove(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(Usuario u)
        {
            throw new NotImplementedException();
        }

        public bool ExisteEmail(string email)
        {
            Usuario u = Contexto.Usuarios.Where(u => u.Email == email).SingleOrDefault();
            return u != null;

        }
    }
}
