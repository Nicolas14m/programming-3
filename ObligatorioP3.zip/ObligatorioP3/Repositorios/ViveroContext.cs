﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Dominio.EntidadesNegocio;
using System.Linq;
namespace Repositorios
{
    public class ViveroContext : DbContext
    {

        public DbSet<Ambiente> Ambientes { get; set; }
        public DbSet<Compra> Compras { get; set; }

        public DbSet<Plaza> Plaza { get; set; }
        public DbSet<Importacion> Importaciones { get; set; }
        public DbSet<TipoIluminacion> TiposIluminacion { get; set; }

        public DbSet<TipoPlanta> TiposPlanta { get; set; }

        public DbSet<Usuario> Usuarios { get; set; }

        public DbSet<Planta> Plantas { get; set; }

        public DbSet<Parametro> Parametros { get; set; }


        public ViveroContext(DbContextOptions<ViveroContext> options)
            : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // FLUENT API

            // Hacemos PK compuesta 
            modelBuilder.Entity<Planta>()
                         .HasMany(p => p.ItemsCompras)
                         .WithOne(p => p.Planta);

            modelBuilder.Entity<Compra>()
                        .HasMany(c => c.ItemsCompras)
                        .WithOne(c => c.Compra);

            modelBuilder.Entity<ItemCompra>()
                        .HasKey(ic => new { ic.PlantaId, ic.CompraId });

            // Que el id de item compra siga siendo identity, ya no es PK
            modelBuilder.Entity<ItemCompra>()
                        .Property(ic => ic.Id)
                        .ValueGeneratedOnAdd();

            modelBuilder.Entity<TipoPlanta>()
            .HasAlternateKey(tp => tp.Nombre)
            .HasName("Unique_TipoPlanta");

            modelBuilder.Entity<Usuario>()
            .HasAlternateKey(u => u.Email)
            .HasName("Unique_Email");

            // Otra manera de hacer unique por si el de arriba da problema:

            // modelBuilder.Entity<TipoPlanta>()
            //.HasIndex(tp => tp.Nombre).IsUnique();

            // modelBuilder.Entity<Usuario>()
            //.HasIndex(u => u.Email).IsUnique();


            base.OnModelCreating(modelBuilder);
        }

       


    }



}

