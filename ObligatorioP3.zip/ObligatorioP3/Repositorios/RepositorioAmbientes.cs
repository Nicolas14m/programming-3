﻿using System;
using System.Collections.Generic;
using System.Text;
using Dominio.EntidadesNegocio;
using Dominio.Interfaces;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Repositorios
{
    public class RepositorioAmbientes : IRepositorioAmbiente
    {

        public ViveroContext Contexto { get; set; }

        public RepositorioAmbientes(ViveroContext ctx)
        {
            Contexto = ctx;
        }


        public Ambiente FindById(int id)
        {
            return Contexto.Ambientes.Find(id);
        }

        public IEnumerable<Ambiente> FindAll()
        {
            return Contexto.Ambientes.ToList();
        }

        public bool Add(Ambiente obj)
        {
            throw new NotImplementedException();
        }

        public bool Remove(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(Ambiente obj)
        {
            throw new NotImplementedException();
        }
    }
}
