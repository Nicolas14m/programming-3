﻿using CasosUso.InterfacesManejadores;
using Dominio.EntidadesNegocio;
using DTOs_Compra;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebAPI_Obligatorio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComprasController : ControllerBase
    {
        public IManejadorCompras ManejadorCompras { get; set; }

        public ComprasController(IManejadorCompras manejadorCompras)
        {
            ManejadorCompras = manejadorCompras;
        }


        // GET: api/<ComprasController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<ComprasController>/5

        [HttpGet("filtrar/{tipoPlanta}")]
        public IActionResult Get(string tipoPlanta)
        {
            try
            {
                if (tipoPlanta == "" || Regex.IsMatch(tipoPlanta, @"^\d+$")) return BadRequest();

                

                IEnumerable<Compra> compras = ManejadorCompras.ObtenerComprasPorTipoPlanta(tipoPlanta);

                IEnumerable<DTO_Planta> dtosPlanta = compras.SelectMany(compra => compra.ItemsCompras).Select(ic => new DTO_Planta()
                {
                   Id = ic.PlantaId,
                   Nombre = ic.Planta.NombreCientifico,
                   Tipo = ic.Planta.Tipo.Nombre,
                   Ambiente = ic.Planta.Ambiente.Nombre,
                   Descripcion = ic.Planta.Descripcion
                   
                   


                });;


                IEnumerable<DTO_Compra> dtosCompra = compras.Select(compra => new DTO_Compra()
                {
                    Id = compra.Id,
                    Fecha = compra.Fecha,
                    Total = compra.CalcTotal(),
                    TasaCobradaIVA = compra is Plaza ? (compra as Plaza).TasaCobradaIVA : 0,
                    TasaCobradaImportacion = compra is Importacion ? (compra as Importacion).TasaCobradaImportacion : 0,
                    PorcentajeDescuentoArancel = compra is Importacion ? (compra as Importacion).PorcentajeDescuentoArancel : 0,
                    PlantasCompra = dtosPlanta


            }); 

                return Ok(dtosCompra);
            }
            catch (Exception)
            {
                return StatusCode(500);
            }
        }

        // POST api/compras/alta/importacion
        [HttpPost]
        [Route("alta/importacion")]
        public IActionResult Post([FromBody] Importacion importacion)
        {
            try
            {

                // Validamos que existen las plantas
                IEnumerable<ItemCompra> itemsCompra = importacion.ItemsCompras;

                IEnumerable<bool> existen = itemsCompra.Select(ic => ManejadorCompras.ExisteTipo(ic.PlantaId));

                if (existen.Any(x => x == false)) return BadRequest("Error al ingresar, no se encontró el ID de alguna de las plantas");

                if (!importacion.Validar()) return BadRequest();

                // Si estan bien las validaciones, le cargamos sus respectivas tasas actuales 
                importacion.TasaCobradaImportacion = ManejadorCompras.ObtenerValorParametro("TasaImportacion");
                importacion.PorcentajeDescuentoArancel = ManejadorCompras.ObtenerValorParametro("PorcentajeDescuentoArancel");

                bool ok = ManejadorCompras.AgregarCompra(importacion);
                if (!ok) return Conflict();

                //return CreatedAtRoute("Get", new { id = importacion.Id }, importacion);

                return Ok(importacion);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }


        // POST api/compras/alta/plaza
        [HttpPost]
        [Route("alta/compraplaza")]
        public IActionResult Post([FromBody] Plaza compraPlaza)
        {
            try
            {

                // Validamos que existen las plantas

                IEnumerable<ItemCompra> itemsCompra = compraPlaza.ItemsCompras;

                IEnumerable<bool> existen = itemsCompra.Select(ic => ManejadorCompras.ExisteTipo(ic.PlantaId));

                if (existen.Any(x => x == false)) return BadRequest("Error al ingresar, no se encontró el ID de alguna de las plantas");
               
                if (!compraPlaza.Validar()) return BadRequest();

                // Le cargamos el valor del IVA actual
                compraPlaza.TasaCobradaIVA = ManejadorCompras.ObtenerValorParametro("IVA");


                bool ok = ManejadorCompras.AgregarCompra(compraPlaza);
                if (!ok) return Conflict();

                //return CreatedAtRoute("Get", new { id = compraPlaza.Id }, compraPlaza);

                return Ok(compraPlaza);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        // PUT api/<ComprasController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {

        }

        // DELETE api/<ComprasController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
